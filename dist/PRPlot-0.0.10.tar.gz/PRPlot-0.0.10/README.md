# PRPlot
for install this library use pip install PRPlot==version. Versions before 0.0.10 (latest) is bad. They didn't work. Use only 0.0.10.