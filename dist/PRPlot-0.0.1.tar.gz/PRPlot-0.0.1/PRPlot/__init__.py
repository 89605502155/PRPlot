from .PRPlot import PRPlot

__author__ = 'Andrey Ferubko and Ivan Krylov'
__version__ = '0.0.1'
__email__ = 'ferubko1999@yandex.ru'