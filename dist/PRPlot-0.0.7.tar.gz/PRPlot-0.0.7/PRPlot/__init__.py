from .PRPlot import PRPlot

__author__ = 'Andrey Ferubko'
__version__ = '0.0.7'
__email__ = 'ferubko1999@yandex.ru'