from .PRPlot import PRPlot

__author__ = 'Andrey Ferubko'
__version__ = '0.0.2'
__email__ = 'ferubko1999@yandex.ru'